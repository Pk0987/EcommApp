<!DOCTYPE html>
<html lang="en">
  <head>

    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style type="text/css">
        .div-center{
            text-align: center;
            padding-top: 40px;
        }
        .h2-font{
            font-size:40px;
            padding-bottom: 40px;
        }
        .center{
            margin-left:15%;
            text-align: center;
            /* border: 2px solid green */
        }
    </style>

  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- page-body-wrapper ends -->
      

        <div class="main-panel">
            <div class="content-wrapper">

                <?php if(@session()->has('message')): ?>
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
                    <?php echo e(session()->get('message')); ?>

                </div>
                <?php endif; ?>

                <div class="div-center">
                    <h2 class="h2-font">Add category</h2>
                        <form  method="POST" action="<?php echo e(route('add_catagory')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="catagory" class="text-dark" placeholder="Write Category Name">
                            <input type="submit" class="mx-3 py-2 px-4 btn btn-info" name="submit" value="Add Category">
                        </form>
                </div>
                <div class="row justify-content-center">
                    <table class="table-responsive-md mt-5 table-striped table-bordered border-white">
                        <thead class="text-center">
                            <tr class="table-success text-dark font-bold">
                                <td class="py-2">Catagory Name</td>
                                <td class="py-2">Action</td>
                            </tr>
                        </thead>
                        <tbody class="">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-dark px-5"><?php echo e($data->catagory_name); ?></td>
                                <td class="py-2 px-5"><a href="<?php echo e(url('delete_catagory',$data->id)); ?>" onclick="return confirm('Are you sure want to delete?')" class="btn btn-outline-danger px-2 text-sm">Delete</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\php\EcommApp\resources\views/admin/catagory.blade.php ENDPATH**/ ?>