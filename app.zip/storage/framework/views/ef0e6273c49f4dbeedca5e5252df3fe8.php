<section class="product_section layout_padding" id="product">
    <div class="container">
        <div class="heading_container heading_center">
            <h2>
                Our <span>products</span>
            </h2>
        </div>
        <div>
            <form method="GET" action="<?php echo e(url('search_product')); ?>">
                <?php echo csrf_field(); ?>
                <div class="text-center mb-3">
                    <input style="width: 70%" type="search" name="search" id="for1" placeholder="Search">
                    <input type="submit" value="Search">
                </div>
            </form>
        </div>
        <div class="row">

            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-4 col-lg-4">
                    <div class="box" style="height: 450px">
                        <div class="option_container">
                            <div class="options">
                                <a href="<?php echo e(url('product_details', $products->id)); ?>" class="option1">
                                    Product Detail
                                </a>
                                <form method="Post" action="<?php echo e(url('add_cart',$products->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="pt-1">
                                            <input name="quantity" type="number"  value="1" min="1" max="<?php echo e($products->quantity); ?>"
                                                style="width: 70px">
                                        </div>
                                        <div class="px-2">
                                            <input type="submit" class="px-2" value="Add to Cart">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="img-box">
                            <img src="<?php echo e(asset('product/' . $products->image)); ?>" alt="">
                        </div>
                        <div class="row detail-box justify-center">
                            <h5 class="mx-auto">
                                <?php echo e($products->title); ?>

                            </h5>

                            <div class="d-flex gap-2 mx-auto " style="widows: 100%">
                                <?php if($products->discount_price != null): ?>
                                    <h6 style="color:red; font-size:15px">
                                        <span>Discount Price </span>
                                        ₹.<?php echo e($products->discount_price); ?> <br>
                                    </h6>
                                    <h6 class="mx-3" style="text-decoration: line-through; color:grey">
                                        <span>Price </span>₹.<?php echo e($products->price); ?>

                                    </h6>
                                <?php else: ?>
                                    <h6 style="color:red">
                                        <span>Price </span>
                                        ₹.<?php echo e($products->price); ?>

                                    </h6>
                                <?php endif; ?>
                             </div>
                            <div class="d-flex mt-2 " style="font-size:13px">

                                    <p><?php echo e($products->description); ?></p>

                                    <p class="text-bold">Available Quantity: <span style="font-weight: 500"><?php echo e($products->quantity); ?></span></p>

                            </div>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="mt-3 mx-5">
            <span style="padding-top: 20px">
                <?php echo $product->links('pagination::bootstrap-5'); ?>

            </span>
        </div>

    </div>
</section>
<?php /**PATH C:\xampp\htdocs\php\EcommApp\resources\views/home/product.blade.php ENDPATH**/ ?>