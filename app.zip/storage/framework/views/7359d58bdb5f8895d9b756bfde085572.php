<!DOCTYPE html>
<html lang="en">
    <head>

        <base href="/public">

    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style type="text/css">
        .div-center{
            text-align: center;
        }
        .h2-font{
            font-size:40px;
            padding-bottom: 40px;
        }
        .center{
            margin-left:15%;
            text-align: center;
            /* border: 2px solid green */
        }
        .text-color{
            color: black;
            padding-bottom: 2px;
        }
        label, .img {
            display: inline-block;
            width: 200px;
        }
        .design{
            padding: 10px;
        }
    </style>
  </head>
  <body>
      <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- page-body-wrapper ends -->
      

        <div class="main-panel">
            <div class="content-wrapper">

                <?php if(@session()->has('message')): ?>
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
                    <?php echo e(session()->get('message')); ?>

                </div>
                <?php endif; ?>

                <div class="div-center">
                    <h2 class="h2-font">Add Product</h2>

                    <form method="POST" action="<?php echo e(url('/edit_product',$product->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="design">
                            <label for="">Product Title :<span class="text-danger">*</span></label>
                            <input type="text" class="text-color" value="<?php echo e($product->title); ?>" name="title" placeholder="Enter a Title" required>
                        </div>
                        <div class="design">
                            <label for="">Product Description : <span class="text-danger">*</span></label>
                            <input type="text" class="text-color" value="<?php echo e($product->description); ?>" name="description" placeholder="Enter a Description" required>
                        </div>
                        <div class="design">
                            <label for="">Product Price :<span class="text-danger">*</span></label>
                            <input type="text" class="text-color" value="<?php echo e($product->price); ?>" name="price" placeholder="Enter a Price" required>
                        </div>
                        <div class="design">
                            <label for="">Discount Price :<span class="text-danger">*</span></label>
                            <input type="text" class="text-color" value="<?php echo e($product->discount_price); ?>" name="discount_price" placeholder="Enter a Discount Price" required>
                        </div>
                        <div class="design">
                            <label for="">Product Quantity :<span class="text-danger">*</span></label>
                            <input type="text" class="text-color" value="<?php echo e($product->quantity); ?>" name="quantity" placeholder="Enter a Quantity" required>
                        </div>
                        <div class="design">
                            <label for="">Product Catagory :<span class="text-danger">*</span></label>
                            <select class="text-color" value="<?php echo e($product->catagory); ?>" name="catagory" required>
                                <option selected="">Add a catagory here</option>
                                    <?php $__currentLoopData = $catagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($catagory->catagory_name); ?>"><?php echo e($catagory->catagory_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="design">
                            <label for="">Product Image :<span class="text-danger">*</span></label>
                            <input type="file" value="<?php echo e($product->image); ?>" class="img text-color" name="image" placeholder="Enter a Image" required>
                        </div>
                        <div class="design">
                            <input type="submit" value="Add product" class="btn btn-primary">
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\php\EcommApp\resources\views/admin/update-product.blade.php ENDPATH**/ ?>