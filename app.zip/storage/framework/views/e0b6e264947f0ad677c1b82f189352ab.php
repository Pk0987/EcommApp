<!DOCTYPE html>
<html lang="en">
  <head>

    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style type="text/css">
        .div-center{
            text-align: center;
        }
        .h2-font{
            font-size:40px;
        }   
        .center{
            margin-left:15%;
            text-align: center;
            /* border: 2px solid green */
        }
    </style>

  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- page-body-wrapper ends -->
      

      <div class="main-panel">
        <div class="content-wrapper">

            <div class="div-center">
                <h2 class="h2-font text-white mb-4">All Orders</h2>
                
            </div>
            <div>
                <form method="get" action="<?php echo e(url('search')); ?>">
                    <div class="text-center mb-3">
                        <input style="width: 50%" class="rounded-sm" type="search" name="search" id="for1" placeholder="Search">
                    </div>
                </form>
            </div>
            <?php if(@session()->has('message')): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
                <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="table-responsive" style="width: 90%">
                <table class="table custom-table table-striped mt-3 table-bordered">
                    <thead class="text-center">
                        <tr class="table-secondary text-dark font-bold">
                            <td>Name</td>
                            <td>Email</td>
                            <td>Address</td>
                            <td>Phone</td>
                            <td>Product Title</td>
                            <td>Quantity</td>
                            <td>Price</td>
                            <td>Payment Status</td>
                            <td>Delivery Status</td>
                            <td>Image</td>
                            <td>Action</td>
                            <td>Invoice</td>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <?php $__empty_1 = true; $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-dark">
                            <td class="px-3"><?php echo e($order->name); ?></td>
                            <td class="px-3"><?php echo e($order->email); ?></td>
                            <td class="px-3"><?php echo e($order->address); ?></td>
                            <td class="px-3"><?php echo e($order->phone); ?></td>
                            <td class="px-3"><?php echo e($order->product_title); ?></td>
                            <td class="px-3"><?php echo e($order->quantity); ?></td>
                            <td class="px-3"><?php echo e($order->price); ?></td>
                            <td class="px-3">
                                <?php if($order->payment_status == 'Paid'): ?>
                                <p class="badge badge-success rounded-pill d-inline px-3">Paid</p>
                                <?php else: ?>
                                <p class="badge badge-warning rounded-pill d-inline px-2"><?php echo e($order->payment_status); ?></p>
                                <?php endif; ?>
                            </td>
                            <td class="px-3">
                                <?php if($order->delivery_status == 'Processing'): ?>
                                <p class="badge badge-warning rounded-pill d-inline px-3"><?php echo e($order->delivery_status); ?></p>
                                <?php else: ?>
                                <p class="badge badge-success rounded-pill d-inline px-3"><?php echo e($order->delivery_status); ?></p>
                                <?php endif; ?>
                            </td>
                            <td class="px-3 w-30 h-20">
                                <img src="<?php echo e(asset('product/'.$order->image)); ?>" class="mx-auto w-30 h-15" alt="Product-Image" width="40px" height="20px">
                            </td>
                            <td class="py-2 px-3">
                                <div class="d-flex gap-2 text-center">
                                    <?php if($order->delivery_status == 'Processing'): ?>
                                    <a href="<?php echo e(url('delivered',$order->id)); ?>" onclick="return confirm('Are you sure the product could to delivered?')" class="btn btn-warning text-dark  text-sm px-2 mx-auto">
                                    Delivered
                                    </a>
                                    <?php else: ?>
                                    <p class="badge badge-success rounded-pill d-inline px-3">Delivered</p>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="py-2 px-3">
                                <div class="d-flex gap-2 text-center">
                                    <a href="<?php echo e(url('download_pdf',$order->id)); ?>" class="text-primary mx-auto" data-toggle="tooltip" data-placement="top" title="Download PDF">
                                    <u>Download</u>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            <td colspan="16" class="text-white">No data found</td>
                        </tr>

                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    </div>
    <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\php\EcommApp\resources\views/admin/order.blade.php ENDPATH**/ ?>