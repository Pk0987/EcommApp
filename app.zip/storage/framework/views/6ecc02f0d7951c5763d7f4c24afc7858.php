
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <base href="/public">
    <style type="text/css">
        .div-center{
            text-align: center;
            padding-top: 40px;
        }
        .h2-font{
            font-size:40px;
            padding-bottom: 40px;
            color: black;
        }
        .center{
            margin-left:15%;
            text-align: center;
            /* border: 2px solid green */
        }
    </style>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
      <!-- partial -->
      <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- page-body-wrapper ends -->
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-panel">
            <div class="content-wrapper">

                <?php if(@session()->has('message')): ?>
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
                    <?php echo e(session()->get('message')); ?>

                </div>
                <?php endif; ?>

                <div class="div-center">
                    <h2 class="h2-font">Product List</h2>
                    <a href="<?php echo e(url('view_product')); ?>" type="button" class="absolute btn btn-outline-info float-end right-[100px]">Add Product</a>
                </div>

                <div class="table-responsive justify-items-center" style="width: 90%">
                    <table class="table mt-5 table-striped table-bordered">
                        <thead class="text-center">
                            <tr class="table-secondary text-dark font-bold">
                                <td class="py-2">#</td>
                                <td class="py-2">Title</td>
                                <td class="py-2">Image</td>
                                <td class="py-2">Description</td>
                                <td class="py-2">Price</td>
                                <td class="py-2">Catagory</td>
                                <td class="py-2">Discount Price</td>
                                <td class="py-2">Action</td>
                            </tr>
                        </thead>
                        <tbody class="">
                            <?php if($product->count() > 0): ?>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-dark px-3"><?php echo e($product->id); ?></td>
                                <td class="text-dark px-3"><?php echo e($product->title); ?></td>
                                <td class="text-dark px-3"><img src="<?php echo e(asset('product/'.$product->image)); ?>" alt="Product-Image" width="20px" height="20px"></td>
                                <td class="text-dark px-3"><?php echo e($product->description); ?></td>
                                <td class="text-dark px-3"><?php echo e($product->price); ?></td>
                                <td class="text-dark px-3"><?php echo e($product->catagory); ?></td>
                                <td class="text-dark px-3">
                                    <?php if($product->discount_price !== null): ?>
                                    <p class="text-center"><?php echo e($product->discount_price); ?></p>
                                    <?php else: ?>
                                    <p class="text-center">-</p>
                                    <?php endif; ?>
                                </td>
                                <td class="py-2 px-3">
                                    <div class="d-flex gap-2">
                                        <a href="<?php echo e(url('update_product',$product->id)); ?>" class="btn btn-outline-info px-2" data-toggle="tooltip" data-placement="top" title="Edit"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="currentColor" d="m14.06 9l.94.94L5.92 19H5v-.92zm3.6-6c-.25 0-.51.1-.7.29l-1.83 1.83l3.75 3.75l1.83-1.83c.39-.39.39-1.04 0-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29m-3.6 3.19L3 17.25V21h3.75L17.81 9.94z"/></svg></a>
                                        <a href="<?php echo e(url('delete_product',$product->id)); ?>" onclick="return confirm('Are you sure want to delete?')" class="btn btn-outline-danger px-2" data-toggle="tooltip" data-placement="top" title="Delete"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="currentColor" d="M9 3v1H4v2h1v13a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V6h1V4h-5V3zM7 6h10v13H7zm2 2v9h2V8zm4 0v9h2V8z"/></svg></a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr  style="color: white">
                                <td colspan="16" class="text-center text-dark">
                                    <p>Product list is empty</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\EcommApp\resources\views/admin/show-product.blade.php ENDPATH**/ ?>