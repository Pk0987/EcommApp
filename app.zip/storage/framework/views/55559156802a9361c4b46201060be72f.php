<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\php\EcommApp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>