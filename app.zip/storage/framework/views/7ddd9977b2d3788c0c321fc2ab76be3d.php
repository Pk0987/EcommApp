<section class="subscribe_section">
    <div class="container-fuild">
       <div class="box">
          <div class="row">
             <div class="col-md-6 offset-md-3">
                <div class="subscribe_form ">
                   <div class="heading_container heading_center">
                      <h3>Subscribe To Get Discount Offers</h3>
                   </div>
                   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
                   <form action="">
                      <input type="email" placeholder="Enter your email">
                      <button>
                      subscribe
                      </button>
                   </form>
                </div>
             </div>
          </div>
       </div>
    </div>
 </section>
<?php /**PATH C:\xampp\htdocs\php\EcommApp\resources\views/home/subscribe.blade.php ENDPATH**/ ?>