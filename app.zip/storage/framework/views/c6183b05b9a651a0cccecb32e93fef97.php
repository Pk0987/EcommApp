
<!DOCTYPE html>
<html>
   <head>
      <!-- Basic -->
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <!-- Site Metas -->
      <meta name="keywords" content="" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <link rel="shortcut icon" href="home/images/favicon.png" type="">
      <title>Famms - Fashion HTML Template</title>
      <!-- bootstrap core css -->
      <link rel="stylesheet" type="text/css" href="home/css/bootstrap.css" />
      <!-- font awesome style -->
      <link href="home/css/font-awesome.min.css" rel="stylesheet" />
      <!-- Custom styles for this template -->
      <link href="home/css/style.css" rel="stylesheet" />
      <!-- responsive style -->
      <link href="home/css/responsive.css" rel="stylesheet" />

      <style type="text/css">
        .div-center{
            text-align: center;
        }
        .h2-font{
            font-size:40px;
        }
        .center{
            margin-left:15%;
            text-align: center;
            /* border: 2px solid green */
        }
    </style>
   </head>
   <body>
      <div class="hero_area">
         <!-- header section strats -->
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- end header section -->

         <div class="main-panel">
            <div class="content-wrapper">

                <div class="div-center">
                    <h2 class="h2-font text-dark mb-4">All Orders</h2>
                    
                </div>
                <div>
                    <form method="get" action="<?php echo e(url('search_order')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="text-center mb-3">
                            <input style="width: 50%" class="rounded-sm" type="search" name="search" id="for1" placeholder="Search">
                        </div>
                    </form>
                </div>
                <?php if(@session()->has('message')): ?>
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
                    <?php echo e(session()->get('message')); ?>

                </div>
                <?php endif; ?>
                <div class="table-responsive" style="width: 70%; margin:auto">
                    <table class="table custom-table table-striped mb-5 table-bordered">
                        <thead class="text-center">
                            <tr class="text-dark font-bold">
                                <td>Product Title</td>
                                <td>Quantity</td>
                                <td>Price</td>
                                <td>Payment Status</td>
                                <td>Delivery Status</td>
                                <td>Image</td>
                                <td>Action</td>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php $__empty_1 = true; $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-dark">
                                <td class="px-3"><?php echo e($order->product_title); ?></td>
                                <td class="px-3"><?php echo e($order->quantity); ?></td>
                                <td class="px-3"><?php echo e($order->price); ?></td>
                                <td class="px-3">
                                    <?php if($order->payment_status == 'Paid'): ?>
                                    <p class="badge badge-success rounded-pill d-inline px-3">Paid</p>
                                    <?php else: ?>
                                    <p class="badge badge-warning rounded-pill d-inline px-2"><?php echo e($order->payment_status); ?></p>
                                    <?php endif; ?>
                                </td>
                                <td class="px-3">
                                    <?php if($order->delivery_status == 'Processing'): ?>
                                    <p class="badge badge-warning rounded-pill d-inline px-3"><?php echo e($order->delivery_status); ?></p>
                                    <?php elseif($order->delivery_status == 'Delivered'): ?>
                                    <p class="badge badge-success rounded-pill d-inline px-3"><?php echo e($order->delivery_status); ?></p>
                                    <?php else: ?>
                                    <p class="badge badge-danger rounded-pill d-inline px-3"><?php echo e($order->delivery_status); ?></p>
                                    <?php endif; ?>
                                </td>
                                <td class="px-3 w-30 h-20">
                                    <img src="<?php echo e(asset('product/'.$order->image)); ?>" class="mx-auto w-30 h-15" alt="Product-Image" width="40px" height="20px">
                                </td>
                                <td class="py-2 px-3">
                                    <div class="d-flex gap-2 text-center">
                                        <?php if($order->delivery_status == 'Processing'): ?>
                                        <a href="<?php echo e(url('order_cancel',$order->id)); ?>" onclick="return confirm('Are you sure want to cancel?')" class="btn-sm rounded btn-danger text-white px-2 mx-auto">
                                        Order Cancel
                                        </a>
                                        <?php elseif($order->delivery_status=='Delivered'): ?>
                                        <p class="badge badge-success rounded-pill d-inline px-3">Delivered</p>
                                        <?php else: ?>
                                        <p class="badge badge-danger rounded-pill d-inline px-">Order canceled</p>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>
                                <td colspan="16" class="text-dark">No data found</td>
                            </tr>

                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

</div>
      <!-- end client section -->
      <!-- footer start -->
      <!-- footer end -->
      <div class="cpy_">
         <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>
            Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>
         </p>
      </div>
      <!-- jQery -->
      <script src="home/js/jquery-3.4.1.min.js"></script>
      <!-- popper js -->
      <script src="home/js/popper.min.js"></script>
      <!-- bootstrap js -->
      <script src="home/js/bootstrap.js"></script>
      <!-- custom js -->
      <script src="home/js/custom.js"></script>
   </body>
</html>
<?php /**PATH C:\xampp\htdocs\php\EcommApp\resources\views/home/show_order.blade.php ENDPATH**/ ?>